import { Component } from '@angular/core';

@Component({
  selector: 'app-first',
  standalone: true,
  imports: [],
  templateUrl: './first.component.html',
  styleUrl: './first.component.css'
})
export class FirstComponent 
{
  public Name = "";
  public str = "marvellous infosystem";
  public btn = "";
  public fun()
  {
    return "Marvellous Infosystem";
  }
  
  public Event()
  {
    this.Name = "Educating for better tommorow";
  }

  public uppercase()
  {
    this.btn = this.str.toUpperCase();
  }

  public lowercase()
  {
    this.btn = this.str.toLowerCase();
  }
}
